# This is just something I made for fun :)


### Install instructions
1) Run the command "pip install PointSystem"
2) to import it use this "import src.PointSystem_Totallyahuman15.PointSystem"
